from pathlib import Path
import cairosvg
ROOT=Path(__file__).resolve().parents[1]
SVG=ROOT/'02_svg'; PNG=ROOT/'03_png'; PDF=ROOT/'04_pdf'
C={'teal':'#0D6EA8','deep':'#084A72','gold':'#C9962B','cream':'#F3F7FA','ink':'#1A1A1A','white':'#FFFFFF'}
font='Arial, Helvetica, sans-serif'
def doc(body,w,h,bg='none'):
 return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc"><title id="title">Place logo refinement</title><desc id="desc">Refined Place concept, editable SVG</desc><rect width="100%" height="100%" fill="{bg}"/>{body}</svg>'''
def save(name,body,w=1200,h=420,bg='none'):
 (SVG/name).write_text(doc(body,w,h,bg),encoding='utf-8')
# 02: three asymmetrical destination modules, not a four-square grid. The open route is the identity cue.
sym2=f'''<g transform="translate(34 34)"><path d="M105 72H224V191" fill="none" stroke="{C['cream']}" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"/><circle cx="105" cy="72" r="20" fill="{C['gold']}"/><rect x="0" y="0" width="105" height="105" rx="28" fill="{C['teal']}"/><rect x="147" y="0" width="105" height="105" rx="28" fill="{C['gold']}"/><rect x="0" y="147" width="105" height="105" rx="28" fill="{C['deep']}"/><circle cx="224" cy="224" r="28" fill="{C['ink']}"/></g>'''
body2=sym2+f'''<g fill="{C['ink']}" font-family="{font}"><text x="440" y="210" font-size="174" font-weight="700" letter-spacing="-7">Place</text></g>'''
save('concept-02-modular-mark.svg',body2)
# 03: standalone P-shaped portal. The open lower counter + gold threshold makes the portal intent explicit.
sym3=f'''<g transform="translate(20 20)"><path d="M48 242V38h112c63 0 100 37 100 91s-37 91-100 91h-56v22H48Z" fill="{C['deep']}"/><path d="M104 91v76h45c28 0 45-13 45-38s-17-38-45-38h-45Z" fill="{C['cream']}"/><path d="M35 258h190" fill="none" stroke="{C['gold']}" stroke-width="14" stroke-linecap="round"/><path d="M104 167v47" stroke="{C['cream']}" stroke-width="12" stroke-linecap="round"/></g>'''
body3=sym3+f'''<g fill="{C['ink']}" font-family="{font}"><text x="440" y="220" font-size="174" font-weight="700" letter-spacing="-7">Place</text></g>'''
save('concept-03-portal-mark.svg',body3)
# standalone symbols, transparent
(SVG/'concept-02-symbol.svg').write_text(doc(f'<g transform="translate(20 20)">{sym2}</g>',320,320),encoding='utf-8')
(SVG/'concept-03-symbol.svg').write_text(doc(f'<g transform="translate(0 0)">{sym3}</g>',320,320),encoding='utf-8')
# optional geographic lockups; not mandatory logo.
for n,base,sym in [(2,'concept-02-modular-mark.svg',sym2),(3,'concept-03-portal-mark.svg',sym3)]:
 b=sym+f'''<g fill="{C['ink']}" font-family="{font}"><text x="440" y="205" font-size="174" font-weight="700" letter-spacing="-7">Place</text><rect x="445" y="246" width="340" height="5" rx="2.5" fill="{C['gold']}"/><text x="447" y="311" font-size="38" font-weight="600" letter-spacing="7" fill="{C['deep']}">DJIBOUTI</text></g>'''
 save(f'concept-{n:02d}-place-djibouti.svg',b)
# Place-only named copies for clarity
for n,src in [(2,'concept-02-modular-mark.svg'),(3,'concept-03-portal-mark.svg')]:
 (SVG/f'concept-{n:02d}-place.svg').write_text((SVG/src).read_text(),encoding='utf-8')
# recolor variants and render only 02/03 refined outputs
for n in [2,3]:
 sources=[f'concept-{n:02d}-modular-mark.svg' if n==2 else f'concept-{n:02d}-portal-mark.svg', f'concept-{n:02d}-place-djibouti.svg']
 for srcname in sources:
  src=SVG/srcname; stem=src.stem
  original=src.read_text()
  (SVG/f'{stem}-dark.svg').write_text(original,encoding='utf-8')
  light=original
  for c in [C['teal'],C['deep'],C['gold'],C['ink'],C['cream']]: light=light.replace(c,C['white'])
  light=light.replace('<rect width="100%" height="100%" fill="none"/>',f'<rect width="100%" height="100%" fill="{C["deep"]}"/>')
  (SVG/f'{stem}-light.svg').write_text(light,encoding='utf-8')
  mono=original
  for c in [C['teal'],C['deep'],C['gold']]: mono=mono.replace(c,C['ink'])
  (SVG/f'{stem}-mono.svg').write_text(mono,encoding='utf-8')
  for out in [stem,stem+'-dark',stem+'-light',stem+'-mono']:
   s=SVG/f'{out}.svg'; cairosvg.svg2png(url=str(s),write_to=str(PNG/f'{out}.png'),output_width=1200,output_height=420)
   cairosvg.svg2pdf(url=str(s),write_to=str(PDF/f'{out}.pdf'))
 for sym in [SVG/f'concept-{n:02d}-symbol.svg']:
  cairosvg.svg2png(url=str(sym),write_to=str(PNG/f'concept-{n:02d}-favicon-64.png'),output_width=64,output_height=64)
print('refined concepts 02 and 03')
