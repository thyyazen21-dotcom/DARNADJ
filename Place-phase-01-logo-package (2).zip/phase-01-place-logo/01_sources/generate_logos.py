from pathlib import Path
from textwrap import dedent

ROOT=Path(__file__).resolve().parents[1]
SVG=ROOT/'02_svg'; SVG.mkdir(exist_ok=True)
C={'teal':'#0E7C66','deep':'#0A5D4C','gold':'#C9962B','cream':'#F8F6F1','ink':'#1A1A1A','white':'#FFFFFF','mint':'#E5F6EB'}
font='Arial, Helvetica, sans-serif'

def wrap(body,w,h,view=None,bg='none'):
    v=view or f'0 0 {w} {h}'
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="{v}" role="img" aria-labelledby="title desc"><title id="title">Place logo concept</title><desc id="desc">Original Place brand concept</desc><rect width="100%" height="100%" fill="{bg}"/>{body}</svg>'''

def save(name, body, w=1200,h=420,bg='none'):
    (SVG/name).write_text(wrap(body,w,h,bg=bg),encoding='utf-8')

# Concept 01: disciplined geographic wordmark; gold locator bar makes Djibouti intentional.
body=f'''<g fill="{C['ink']}" font-family="{font}"><text x="70" y="208" font-size="178" font-weight="700" letter-spacing="-7">Place</text><rect x="75" y="246" width="485" height="5" rx="2.5" fill="{C['gold']}"/><text x="77" y="313" font-size="43" font-weight="600" letter-spacing="8" fill="{C['deep']}">DJIBOUTI</text></g><g transform="translate(650 86)"><path d="M83 0c46 0 83 37 83 83 0 66-83 137-83 137S0 149 0 83C0 37 37 0 83 0Z" fill="{C['teal']}"/><circle cx="83" cy="83" r="29" fill="{C['cream']}"/><path d="M83 46v74M46 83h74" stroke="{C['gold']}" stroke-width="8" stroke-linecap="round"/></g>'''
save('concept-01-wordmark.svg',body)

# Concept 02: a modular destination glyph: four tiles make a P / map junction and community.
body=f'''<g transform="translate(72 72)"><rect x="0" y="0" width="124" height="124" rx="28" fill="{C['teal']}"/><rect x="144" y="0" width="124" height="124" rx="28" fill="{C['gold']}"/><rect x="0" y="144" width="124" height="124" rx="28" fill="{C['deep']}"/><path d="M144 144h124v124H144z" fill="{C['ink']}"/><path d="M62 40v188M40 62h188" stroke="{C['cream']}" stroke-width="16" stroke-linecap="round" opacity=".9"/></g><g fill="{C['ink']}" font-family="{font}"><text x="470" y="205" font-size="174" font-weight="700" letter-spacing="-6">Place</text><text x="480" y="286" font-size="34" font-weight="600" letter-spacing="5" fill="{C['teal']}">FIND YOUR PLACE</text></g>'''
save('concept-02-modular-mark.svg',body)

# Concept 03: negative-space doorway / horizon; standalone mark is a P-shaped portal, not a house.
body=f'''<g transform="translate(80 57)"><path d="M0 0h260v306H0z" fill="{C['deep']}" rx="52"/><path d="M67 235V80h87c58 0 92 31 92 78s-34 77-92 77H67Zm59-51h26c22 0 36-9 36-26s-14-27-36-27h-26v53Z" fill="{C['cream']}"/><path d="M26 259h208" stroke="{C['gold']}" stroke-width="12" stroke-linecap="round"/></g><g fill="{C['ink']}" font-family="{font}"><text x="470" y="215" font-size="174" font-weight="700" letter-spacing="-7">Place</text><text x="480" y="296" font-size="34" font-weight="600" letter-spacing="4" fill="{C['deep']}">OPEN THE RIGHT DOOR</text></g>'''
save('concept-03-portal-mark.svg',body)

# standalone marks and theme variants
for i,src in enumerate(['concept-01-wordmark.svg','concept-02-modular-mark.svg','concept-03-portal-mark.svg'],1):
    txt=(SVG/src).read_text()
    # use manually defined compact symbol variants for reliability
    if i==1: sym=f'<path d="M120 0c66 0 120 54 120 120 0 96-120 200-120 200S0 216 0 120C0 54 54 0 120 0Z" fill="{C["teal"]}"/><circle cx="120" cy="120" r="42" fill="{C["cream"]}"/><path d="M120 66v108M66 120h108" stroke="{C["gold"]}" stroke-width="11" stroke-linecap="round"/>'
    elif i==2: sym=f'<rect width="280" height="280" rx="58" fill="{C["teal"]}"/><rect x="140" width="140" height="140" rx="0" fill="{C["gold"]}"/><rect y="140" width="140" height="140" rx="0" fill="{C["deep"]}"/><path d="M140 36v208M36 140h208" stroke="{C["cream"]}" stroke-width="18" stroke-linecap="round"/>'
    else: sym=f'<rect width="280" height="280" rx="58" fill="{C["deep"]}"/><path d="M55 228V52h100c62 0 102 36 102 88s-40 88-102 88H55Zm66-58h31c24 0 40-11 40-30s-16-30-40-30h-31v60Z" fill="{C["cream"]}"/><path d="M28 250h224" stroke="{C["gold"]}" stroke-width="14" stroke-linecap="round"/>'
    (SVG/f'concept-{i:02d}-symbol.svg').write_text(wrap(f'<g transform="translate(20 20)">{sym}</g>',320,320),encoding='utf-8')

print('created',len(list(SVG.glob('*.svg'))),'SVG files')
