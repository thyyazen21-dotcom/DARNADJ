from pathlib import Path
import cairosvg
root=Path(__file__).resolve().parents[1]
svgdir=root/'02_svg'; pngdir=root/'03_png'; pdfdir=root/'04_pdf'
colors=['#0E7C66','#0A5D4C','#C9962B','#1A1A1A','#F8F6F1','#FFFFFF']
for i in range(1,4):
    src=(svgdir/f'concept-{i:02d}-wordmark.svg') if i==1 else (svgdir/f'concept-{i:02d}-modular-mark.svg' if i==2 else svgdir/f'concept-{i:02d}-portal-mark.svg')
    txt=src.read_text()
    # dark: keep original transparent logo
    (svgdir/f'concept-{i:02d}-dark.svg').write_text(txt)
    # light: all non-white brand fills/strokes become white, on deep background
    light=txt
    for c in colors[:-1]: light=light.replace(c,'#FFFFFF')
    light=light.replace('<rect width="100%" height="100%" fill="none"/>','<rect width="100%" height="100%" fill="#0A5D4C"/>')
    (svgdir/f'concept-{i:02d}-light.svg').write_text(light)
    # mono: all brand colors to ink
    mono=txt
    for c in colors[:-2]: mono=mono.replace(c,'#1A1A1A')
    (svgdir/f'concept-{i:02d}-mono.svg').write_text(mono)
for svg in sorted(svgdir.glob('concept-*-dark.svg'))+sorted(svgdir.glob('concept-*-light.svg'))+sorted(svgdir.glob('concept-*-mono.svg')):
    stem=svg.stem
    cairosvg.svg2png(url=str(svg),write_to=str(pngdir/(stem+'.png')),output_width=1200,output_height=420)
    cairosvg.svg2pdf(url=str(svg),write_to=str(pdfdir/(stem+'.pdf')))
for i in range(1,4):
    sym=svgdir/f'concept-{i:02d}-symbol.svg'
    cairosvg.svg2png(url=str(sym),write_to=str(pngdir/f'concept-{i:02d}-favicon-64.png'),output_width=64,output_height=64)
print('variants generated')
